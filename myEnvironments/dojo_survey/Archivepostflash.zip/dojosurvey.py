#source py2FlaskEnv/bin/activate

from flask import Flask, render_template, request, redirect, flash
app = Flask(__name__)
app.secret_key = 'DojoSurvey'

@app.route('/')
def dojosurvey():
    return render_template("dojosurvey.html")

@app.route('/dojosurveypart2', methods=['POST'])
def dojosurveypart2():
    location= request.form['location']
    language = request.form['language']
    name = request.form['name']
    comment = request.form['comment']
    if len(request.form['name'])< 1:
        if len(request.form['comment']) > 121:
            flash("Name cannot be empty and comment cannot be longer than 120 characters!")
            return render_template("dojosurvey.html", name=name)
        if len(request.form['comment']) < 1:
            flash("Name and comment cannot be empty!")
            return render_template("dojosurvey.html", name=name)
        else:
            flash("Name cannot be empty!")
            return render_template("dojosurvey.html", name=name,comment=comment)
    if len(request.form['name'])> 1:
        if len(request.form['comment']) > 121:
            flash("Comment cannot be longer than 120 characters!")
            return render_template("dojosurvey.html", name=name)
        if len(request.form['comment'])<1:
            flash("Comment cannot be empty!")
            return render_template("dojosurvey.html", name=name)
    # recall the name attributes we added to our form inputs
    # to access the data that the user input into the fields we use request.form['name_of_input']

    # redirects back to the '/' route
    return render_template('dojosurveypart2.html', location=location, name=name, language=language, comment=comment)
app.run(debug=True) # run our server

    #accessing data
# request.form['name_of_input']

    #storing the data
# my_data = request.form['name_of_input']

    #redirecting
# return redirect('/route_goes_here')
