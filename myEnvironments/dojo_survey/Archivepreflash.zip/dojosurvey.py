from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def dojosurvey():
    return render_template("dojosurvey.html")

@app.route('/dojosurveypart2', methods=['POST'])
def dojosurveypart2():
    print

    # recall the name attributes we added to our form inputs
    # to access the data that the user input into the fields we use request.form['name_of_input']
    name = request.form['name']
    location= request.form['location']
    language = request.form['language']
    comment = request.form['comment']

    # redirects back to the '/' route
    return render_template('dojosurveypart2.html', location=location, name=name, language=language, comment=comment)
app.run(debug=True) # run our server

    #accessing data
# request.form['name_of_input']

    #storing the data
# my_data = request.form['name_of_input']

    #redirecting
# return redirect('/route_goes_here')
