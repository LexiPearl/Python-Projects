from django.conf.urls import url
from views import dashboard, addPoke, logout
# addBookReview, addReview, bookInfo, userInfo, delete
app_name= "beltTwoApp"
urlpatterns = [
    url(r'^$', dashboard, name='dashboard'),
#     url(r'^addBookReview$', addBookReview, name='addBookReview'),
    url(r'^addPoke/(?P<pokee_id>\d+)$', addPoke, name='addPoke'),
#     url(r'^bookInfo/(?P<book_id>\d+)$', bookInfo, name='bookInfo'),
#     url(r'^userInfo/(?P<id>\d+)$', userInfo, name='userInfo'),
#     url(r'^delete/(?P<id>\d+)$', delete, name='delete'),
    url(r'^logout$', logout, name='logout')
]
