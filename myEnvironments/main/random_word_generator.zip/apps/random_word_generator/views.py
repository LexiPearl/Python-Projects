from django.shortcuts import render, redirect
import random
import string
KEY_LEN=14

def index(request):
    print ("*" *50)
    print(request.method)
    generation = [random.choice(string.letters+string.digits) for i in range (KEY_LEN)]
    random_word = ("".join(generation))
    number = 1
    request.session['random']= {"number" :number, "word" :random_word}
    print request.session['random']
    return render(request, "random_word_generator/index.html")

def random_word(request):
    print(request.method)
    if request.method == "POST":
        print(request.POST)
        generation = [random.choice(string.letters+string.digits) for i in range (KEY_LEN)]
        random_word = ("".join(generation))
        number = request.session['random']['number']+1
        request.session['random']= {"number" :number, "word" :random_word}
        print ("*" *50)
        print request.session['random']
        return redirect("/")
    else:
        return redirect("/")
